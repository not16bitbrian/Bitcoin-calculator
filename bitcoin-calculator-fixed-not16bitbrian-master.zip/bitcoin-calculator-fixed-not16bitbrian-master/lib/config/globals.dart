library globals;

import 'package:http/http.dart' as http;

http.Client httpClient = http.Client();