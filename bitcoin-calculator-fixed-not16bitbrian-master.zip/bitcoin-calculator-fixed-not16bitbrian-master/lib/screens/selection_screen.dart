import 'package:flutter/material.dart';
import 'usd_to_btc_screen.dart';
import 'btc_to_usd_screen.dart';

class SelectionScreen extends StatefulWidget {
  @override
  _SelectionScreen createState() => _SelectionScreen();
}

class _SelectionScreen extends State<SelectionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Conversion Selection'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                key: Key('U2B'),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => USDtoBTCscreen()));
                },
                child: Text('USD to BTC'),
                style: ElevatedButton.styleFrom(
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(20.0)),
                    minimumSize: Size(280, 46),
                    primary: Color(0xff4c748b),
                    onPrimary: Color(0xffffffff))),
            SizedBox(height: 40),
            ElevatedButton(
                key: Key('B2U'),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => BTCtoUSDscreen()));
                },
                child: Text('BTC to USD'),
                style: ElevatedButton.styleFrom(
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(20.0)),
                    minimumSize: Size(280, 46),
                    primary: Color(0xff4c748b),
                    onPrimary: Color(0xffffffff))),
          ],
        ),
      ),
    );
  }
}
