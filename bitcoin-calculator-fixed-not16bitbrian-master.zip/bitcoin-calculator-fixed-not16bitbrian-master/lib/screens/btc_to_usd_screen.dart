import 'package:bitcoin_calculator/utils/BtcAPI.dart';
import 'package:flutter/material.dart';
import 'selection_screen.dart';
import 'package:bitcoin_calculator/utils/convertTools.dart';
import 'package:bitcoin_calculator/config/globals.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BTCtoUSDscreen extends StatefulWidget {
  @override
  _BTCtoUSDscreen createState() => _BTCtoUSDscreen();
}

class _BTCtoUSDscreen extends State<BTCtoUSDscreen> {
  TextEditingController bit = TextEditingController();
  String _errorMessage;
  bool btnEnabled = false;
  double bitcoin = 0;
  String _text = '0 BTC is 0 USD';
  Future<double> futurePrice;

  @override
  void initState(){
    super.initState();
    futurePrice = BtcAPI.fetchPrice(httpClient);
  }

  @override
  void dispose() {
    bit.dispose();
    super.dispose();
  }

  bool _isValidNumber(String value) {
    if (value == null || value.isEmpty) {
      return false;
    }
    final number = num.tryParse(value);
    if (number == null || number.isNegative) {
      return false;
    }
    return true;
  }

  bool isEmpty() {
    setState(() {
      bitcoin = double.parse(bit.text);
      if (bitcoin != null && bitcoin > 0) {
        btnEnabled = true;
      } else
        btnEnabled = false;
    });
    return btnEnabled;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
      floatingActionButton: FloatingActionButton(
        key: Key('back-button'),
        child: Icon(Icons.arrow_back_ios),
        foregroundColor: Color(0xff4c748b),
        backgroundColor: Color(0xfff3f3f3),
        mini: true,
        elevation: 0,
        onPressed: () {
          Navigator.pop(context,
              MaterialPageRoute(builder: (context) => SelectionScreen()));
        },
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Text(
            //   '${_text}',
            //   key: Key('finalValue'),
            // ),
            Text('BTC to USD',
                    key: Key('USD-page'), style: TextStyle(fontSize: 20)),
                Padding(padding: const EdgeInsets.all(8)),
                FutureBuilder<double>(
                    future: futurePrice,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        double btcapi = snapshot.data;
                        if(bitcoin > 0){
                          return Text(
                          "${bitcoin} BTC is ${ConvertTools.convertToUSD(bitcoin, btcapi)} USD",
                          key: Key('finalValue'),
                        );
                        }
                        else{
                          return Text(
                          "0.0 BTC is 0.0 USD",
                          key: Key('finalValue'),
                        );
                        }
                      } 
                      else if (snapshot.hasError) {
                        return Text("${snapshot.error}");
                      }
                      return CircularProgressIndicator();
                    }),
            SizedBox(height: 8),
            ConstrainedBox(
              constraints: BoxConstraints.tightFor(width: 337, height: 48),
              child: TextField(
                keyboardType: TextInputType.number,
                controller: bit,
                onChanged: (value) {
                  isEmpty();
                },
                key: Key('btc-text-field'),
                decoration: InputDecoration(
                    hintText: 'Enter amount in BTC',
                    errorText: _errorMessage,
                    enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff4c748b), width: 2.0),
                        borderRadius: BorderRadius.circular(10.0)),
                    focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff4c748b), width: 2.0),
                        borderRadius: BorderRadius.circular(10.0))),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
                key: Key('CONVERT'),
                onPressed: btnEnabled ? () {
                  setState(() {
                    
                  });
                } : null ,
                child: Text('Convert to USD'),
                style: ElevatedButton.styleFrom(
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(20.0)),
                    minimumSize: Size(280, 46),
                    primary: Color(0xff4c748b),
                    onPrimary: Color(0xffffffff))),
          ],
        ),
      ),
    );
  }
}
