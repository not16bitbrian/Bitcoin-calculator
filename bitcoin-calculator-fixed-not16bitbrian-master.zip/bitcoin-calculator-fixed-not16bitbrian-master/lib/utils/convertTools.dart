class ConvertTools {

  static double convertToBTC(double dollar, double btcapi) {
    if (dollar < 0) {
      throw ArgumentError();
    } 
    return double.parse((dollar / btcapi).toStringAsFixed(6));
  }

  static double convertToUSD(double bitcoin, double btcapi) {
    if (bitcoin < 0) {
      throw ArgumentError();
    }
    return double.parse((bitcoin * btcapi).toStringAsFixed(2));
  }
}