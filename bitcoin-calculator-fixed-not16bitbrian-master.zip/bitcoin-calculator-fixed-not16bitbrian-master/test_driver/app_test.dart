// Imports the Flutter Driver API.
import 'package:flutter_driver/flutter_driver.dart';
import 'package:test/test.dart';

void main() {
  FlutterDriver driver;

  // Connect to the Flutter driver before running any tests.
  setUpAll(() async {
    driver = await FlutterDriver.connect();
  });

  // Close the connection to the driver after the tests have completed.
  tearDownAll(() async {
    if (driver != null) {
      driver.close();
    }
  });

  group('Happy Paths', () {
    //   /*
    //     Given I am on the Conversion Selection Screen
    //     When I tap "USD to BTC"
    //     And I enter "56209.5488"
    //     And I tap "Convert"
    //     Then I should see "56209.5488 USD is 2.0 BTC"
    //   */
    final usdTObtcButton = find.byValueKey('U2B');
    final btcTOusdButton = find.byValueKey('B2U');
    final btcTextField = find.byValueKey('btc-text-field');
    final usdTextField = find.byValueKey('usd-text-field');
    final convert = find.byValueKey('CONVERT');
    final convertedValue = find.byValueKey('finalValue');
    final back = find.byValueKey('back-button');

    test("should convert USD to BTC", () async {
      await driver.tap(usdTObtcButton);
      await driver.tap(usdTextField);
      await driver.enterText('56209.5488');
      await driver.tap(convert);
      //displays converted value
      expect(await driver.getText(convertedValue), "56209.5488 USD is 2.0 BTC");
      await driver.tap(back);
    });
    //   /*
    //     Given I am on the Conversion Selection Screen
    //     When I tap "BTC to USD"
    //     And I enter "2"
    //     And I tap "Convert"
    //     Then I should see "2 USD is 56209.5488 BTC"
    //   */
    test("should convert BTC to USD", () async {
      await driver.tap(btcTOusdButton);
      await driver.tap(btcTextField);
      await driver.enterText('2');
      await driver.tap(convert);
      //displays converted value
      expect(await driver.getText(convertedValue), "2.0 BTC is 56209.55 USD");
      await driver.tap(back);
    });
  });

  group('Sad Paths', () {
    final usdTObtcButton = find.byValueKey('U2B');
    final btcTOusdButton = find.byValueKey('B2U');
    final btcTextField = find.byValueKey('btc-text-field');
    final usdTextField = find.byValueKey('usd-text-field');
    final back = find.byValueKey('back-button');
    final convertedValue = find.byValueKey('finalValue');

    test("should reject a letter for USD to BTC", () async {
      await driver.tap(usdTObtcButton);
      await driver.tap(usdTextField);
      await driver.enterText('k');
      await driver.waitFor(find.text("k"));
// the button is not enabled if you type K so nothing should happen
      expect(await driver.getText(convertedValue), "0.0 USD is 0.0 BTC");
      await driver.tap(back);
    });

    test("should reject a value less than 0 for USD to BTC", () async {
      await driver.tap(usdTObtcButton);
      await driver.tap(usdTextField);
      await driver.enterText('-2');
      await driver.waitFor(find.text("-2"));
//the button is not enabled if you type -2 so nothing should happen
      expect(await driver.getText(convertedValue), "0.0 USD is 0.0 BTC");
      await driver.tap(back);
    });

    test("should reject a letter for BTC to USD", () async {
      await driver.tap(btcTOusdButton);
      await driver.tap(btcTextField);
      await driver.enterText('k');
      await driver.waitFor(find.text("k"));
      
      expect(await driver.getText(convertedValue), "0.0 BTC is 0.0 USD");
      await driver.tap(back);
    });

    test("should reject a value less than 0 for BTC to USD", () async {
      await driver.tap(btcTOusdButton);
      await driver.tap(btcTextField);
      await driver.enterText('-2');
      await driver.waitFor(find.text("-2"));

      expect(await driver.getText(convertedValue), "0.0 BTC is 0.0 USD");
      await driver.tap(back);
    });
  });

  group('Screen navigation is fluid because', () {
    final usdTObtcButton = find.byValueKey('U2B');
    final btcTOusdButton = find.byValueKey('B2U');
    final back = find.byValueKey('back-button');

    test("Back button for USD to BTC page works after moving to it", () async {
      await driver.tap(usdTObtcButton);
      //confirms we navigated to usd to btc screen
      await driver.waitFor(find.text("0.0 USD is 0.0 BTC"));
      //confirms we hit the back button here
      await driver.tap(back);
      //confirms on conversion selection (Both options should be on screen)
      await driver.waitFor(find.text("USD to BTC"));
      await driver.waitFor(find.text("BTC to USD"));
    });

    test("Back button for BTC to USD page works after moving to it", () async {
      await driver.tap(btcTOusdButton);
      //confirms we navigated to usd to btc screen
      await driver.waitFor(find.text("0.0 BTC is 0.0 USD"));
      //confirms we hit the back button here
      await driver.tap(back);
      //confirms on conversion selection (Both options should be on screen)
      await driver.waitFor(find.text("BTC to USD"));
      await driver.waitFor(find.text("USD to BTC"));
    });
  });
}
