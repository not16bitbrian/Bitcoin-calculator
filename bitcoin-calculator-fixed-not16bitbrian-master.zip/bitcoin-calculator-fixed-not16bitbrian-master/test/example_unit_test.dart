import 'package:bitcoin_calculator/utils/BtcAPI.dart';
import 'package:test/test.dart';
import 'package:bitcoin_calculator/utils/convertTools.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;

class MockClient extends Mock implements http.Client {}

void main() {

  group("Mockito", () {
     test('returns a value if the http call completes successfully', () async {
      final client = MockClient();
      final fakeBtcAPIData = '{"time":{"updated":"Apr 3, 2023 00:47:00 UTC","updatedISO":"2023-04-03T00:47:00+00:00","updateduk":"Apr 3, 2023 at 01:47 BST"},"disclaimer":"This data was produced from the CoinDesk Bitcoin Price Index (USD). Non-USD currency data converted using hourly conversion rate from openexchangerates.org","bpi":{"USD":{"code":"USD","rate":"28,104.7744","description":"United States Dollar","rate_float":28104.7744}}}';

      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url))
      .thenAnswer((_) async => http.Response(fakeBtcAPIData, 200));

      double price = await BtcAPI.fetchPrice(client);

      expect(price, isA<double>());

      expect(price, 28104.7744);
     });

    test('throws an exception if the http call completes with an error', () {
      final client = MockClient();
      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url))
      .thenAnswer((_) async => http.Response('Not Found', 404));

      expect(BtcAPI.fetchPrice(client), throwsException);
    });
    
  });
  group("USD to BTC", () {
    test('conversion does not accept negative value', () async {
      final client = MockClient();
      final fakeBtcAPIData = '{"time":{"updated":"Apr 3, 2023 00:47:00 UTC","updatedISO":"2023-04-03T00:47:00+00:00","updateduk":"Apr 3, 2023 at 01:47 BST"},"disclaimer":"This data was produced from the CoinDesk Bitcoin Price Index (USD). Non-USD currency data converted using hourly conversion rate from openexchangerates.org","bpi":{"USD":{"code":"USD","rate":"28,104.7744","description":"United States Dollar","rate_float":28104.7744}}}';

      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url)).thenAnswer((_) async => http.Response(fakeBtcAPIData, 200));

      double price = await BtcAPI.fetchPrice(client);
      expect(() => ConvertTools.convertToBTC(-1, price), throwsArgumentError);
    });

    test('conversion produces the correct amount', () async{
      final client = MockClient();
      final fakeBtcAPIData = '{"time":{"updated":"Apr 3, 2023 00:47:00 UTC","updatedISO":"2023-04-03T00:47:00+00:00","updateduk":"Apr 3, 2023 at 01:47 BST"},"disclaimer":"This data was produced from the CoinDesk Bitcoin Price Index (USD). Non-USD currency data converted using hourly conversion rate from openexchangerates.org","bpi":{"USD":{"code":"USD","rate":"28,104.7744","description":"United States Dollar","rate_float":28104.7744}}}';

      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url)).thenAnswer((_) async => http.Response(fakeBtcAPIData, 200));

      double price = await BtcAPI.fetchPrice(client);
      expect(ConvertTools.convertToBTC(28104.7744, price), 1.0);
    });
  });
  group("BTC to USD", () {
    test('conversion does not accept negative value', () async {
      final client = MockClient();
      final fakeBtcAPIData = '{"time":{"updated":"Apr 3, 2023 00:47:00 UTC","updatedISO":"2023-04-03T00:47:00+00:00","updateduk":"Apr 3, 2023 at 01:47 BST"},"disclaimer":"This data was produced from the CoinDesk Bitcoin Price Index (USD). Non-USD currency data converted using hourly conversion rate from openexchangerates.org","bpi":{"USD":{"code":"USD","rate":"28,104.7744","description":"United States Dollar","rate_float":28104.7744}}}';

      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url)).thenAnswer((_) async => http.Response(fakeBtcAPIData, 200));

      double price = await BtcAPI.fetchPrice(client);
      expect(() => ConvertTools.convertToUSD(-1, price), throwsArgumentError);
    });

    test('conversion produces the correct amount', () async{
      final client = MockClient();
      final fakeBtcAPIData = '{"time":{"updated":"Apr 3, 2023 00:47:00 UTC","updatedISO":"2023-04-03T00:47:00+00:00","updateduk":"Apr 3, 2023 at 01:47 BST"},"disclaimer":"This data was produced from the CoinDesk Bitcoin Price Index (USD). Non-USD currency data converted using hourly conversion rate from openexchangerates.org","bpi":{"USD":{"code":"USD","rate":"28,104.7744","description":"United States Dollar","rate_float":28104.7744}}}';

      var url = Uri.parse('https://api.coindesk.com/v1/bpi/currentprice/usd.json');
      when(client.get(url)).thenAnswer((_) async => http.Response(fakeBtcAPIData, 200));

      double price = await BtcAPI.fetchPrice(client);
      expect(ConvertTools.convertToUSD(1, price), 28104.77);
    });
  });
}
